  function [Ak S]=cerinta3(image, k)
  A=imread(image);
  A=double(A);
  s=0;
  t=1;
  [m,n]=size(A);
  miu=zeros(m,1);
  
  for i=1:m
    for j=1:n
       s = s + A(i,j);
    endfor
    miu(i,1)=s/n;
    s=0;
  endfor
  A = A - miu;
  Z=A'/sqrt(n-1);
  [U S V] = svd(Z);
  W=V(:,1:k);
  Y=W'*A;
  Ak=W*Y+miu;

  endfunction