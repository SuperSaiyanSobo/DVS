function A_k = cerinta1 (image, k)
    
    %Citesc imaginea primita ca parametru
    A=imread(image);
    %Fac cast double la A
    A=double(A);

    [m,n]=size(A);
    [U,S,V]=svd(A);
    %Elimin m-k linii si n-k coloane din S   
    S(:,i=k+1:n)=[];
    S(i=k+1:m,:)=[];
   %Elimin m-k coloane din U
    U(:,i=k+1:m)=[];
    %Elimin n-k linii din V
    V=V';
    V(i=k+1:n,:)=[];
    %Construiesc matricea A_k
    A_k = U*S*V;
endfunction