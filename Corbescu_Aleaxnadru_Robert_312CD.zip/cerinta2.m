function cerinta2()
  
  %cerinta 2.1:
  %Citesc imaginea primita ca parametru
  A=imread('in/images/image2.gif');
  %Fac cast double la A
  A=double(A);
  %Obtin nr de linii si coloane ale matricii;
  [m,n]=size(A);
  [U,S,V]=svd(A);
  %Realizez graficul pt valorile de pe diagonala lui S
  subplot(2,2,1);
  plot(diag(S))
  title("diag(S)");
  
  %Cerinta 2.2:
  k = 1:min(m,n);
  sum1=0;
  sum2=0;
  %Calculez a doua suma
  i=1;
  while(i<=min(m,n))
    sum2=sum2+S(i,i);
    i++;
  endwhile
  %Calculez prima suma si construiesc vectorul info
  t=1;
  while(t<=length(k))
    i=1;
    %Calculez prima suma pentru a construi vectorul info
    while(i<=k(t))
      sum1=sum1+S(i,i);
      i++;
    endwhile
  info(t)=sum1/sum2;
  sum1=0;
  t++;
  endwhile
  %Realizez graficul pentru informatia data pe primele valori k singulare
  subplot(2,2,2);
  plot(k,info);
  title("Informatia");
  
  %Cerinta 2.3:
  %Aplic cerinta1 pentru fiecare t (t->k)
  for t=1:length(k)
    A_k = cerinta1('in/images/image2.gif',t);
    sum=0;
    %Calculez suma pentru fiecare element din vectorul eroarea
    for i=1:m
      for j=1:n
        sum=sum+(A(i,j)-A_k(i,j))^2;
      endfor
    endfor
    %Aplic formula din pdf
    eroarea(t)=sum/(m*n);
  endfor
  %Realizez graficul pentru aproximarea erorii
  subplot(2,2,3);
  plot(k,eroarea);
  title("Eroarea aproximarii");
  
  %cerinta 2.4:
  %schimb vectorul k deoare pentru k = 1:min(m,n) in grafic apare o linie in
  %plus si nu am reusit sa corectez altfel
  k = [1:19 20:20:99 100:30:min(m,n)];
  i=1;
  %Aplic formula pentru fiecare elem din k
  while(i<=length(k))
    compresie(i)=(m*k(i)+n*k(i)+k(i))/(m*n);
     i++;
  endwhile
  %Realizez graficul pentru rata compresiei
  subplot(2,2,4);
  plot(k,compresie);
  title("Rata de compresie");
endfunction